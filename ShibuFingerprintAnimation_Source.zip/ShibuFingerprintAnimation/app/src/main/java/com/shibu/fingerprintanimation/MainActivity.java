package com.shibu.fingerprintanimation;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final String[] icons = {"Tắt icon", "Vân tay", "Vòng tròn", "Cung", "Shibu"};
    private final String[] anims = {"Sakura", "Energy", "Eclipse", "Particles", "Neon"};
    private int iconIndex, animIndex;
    private AnimationView preview;
    private LinearLayout iconRow, animRow;
    private SeekBar sizeBar, offsetBar, speedBar;
    private TextView sizeValue, offsetValue, speedValue;
    private CheckBox screenOn;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        loadPrefs();
        setContentView(buildUi());
        updatePreview();
    }

    private void loadPrefs() {
        SharedPreferences sp = Prefs.get(this);
        iconIndex = sp.getInt(Prefs.ICON, 1);
        animIndex = sp.getInt(Prefs.ANIM, 0);
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1,-2));

        TextView title = text("Shibu Fingerprint", 28, Color.WHITE, true);
        root.addView(title);
        TextView sub = text("Galaxy A31 • hiệu ứng vân tay overlay không root", 14, Color.rgb(170,170,180), false);
        root.addView(sub, lp(-1,-2,0,4,0,16));

        FrameLayout phone = new FrameLayout(this);
        phone.setBackground(round(Color.rgb(18,18,23), 28, Color.rgb(63,63,74), 2));
        preview = new AnimationView(this);
        phone.addView(preview, new FrameLayout.LayoutParams(-1,-1));
        TextView hint = text("XEM TRƯỚC", 11, Color.rgb(150,150,160), true);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2,-2, Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        hp.topMargin = dp(14); phone.addView(hint,hp);
        root.addView(phone, lp(-1, dp(330),0,0,0,18));

        root.addView(section("BIỂU TƯỢNG VÂN TAY"));
        iconRow = chipRow(icons, true);
        root.addView(horizontal(iconRow), lp(-1,dp(66),0,4,0,14));

        root.addView(section("HOẠT ẢNH"));
        animRow = chipRow(anims, false);
        root.addView(horizontal(animRow), lp(-1,dp(66),0,4,0,14));

        sizeValue = valueLabel();
        root.addView(settingHeader("Kích thước", sizeValue));
        sizeBar = bar(0,110, Prefs.get(this).getInt(Prefs.SIZE, 55));
        root.addView(sizeBar);

        offsetValue = valueLabel();
        root.addView(settingHeader("Vị trí từ đáy màn hình", offsetValue));
        offsetBar = bar(0,220, Prefs.get(this).getInt(Prefs.OFFSET, 95));
        root.addView(offsetBar);

        speedValue = valueLabel();
        root.addView(settingHeader("Tốc độ", speedValue));
        speedBar = bar(0,100, Prefs.get(this).getInt(Prefs.SPEED, 50));
        root.addView(speedBar);

        screenOn = new CheckBox(this);
        screenOn.setText("Hiện 4 giây khi màn hình bật");
        screenOn.setTextColor(Color.WHITE);
        screenOn.setTextSize(16);
        screenOn.setChecked(Prefs.get(this).getBoolean(Prefs.SCREEN_ON, true));
        root.addView(screenOn, lp(-1,-2,0,10,0,8));

        TextView note = text("Lưu ý: Android không cho app thường thay trực tiếp hoạt ảnh vân tay của SystemUI. Bản này dùng lớp phủ không chặn cảm ứng. Trên một số bản One UI, Samsung có thể ẩn lớp phủ khi màn hình khóa bảo mật đang hiện.", 13, Color.rgb(175,175,185), false);
        note.setPadding(dp(14),dp(12),dp(14),dp(12));
        note.setBackground(round(Color.rgb(24,24,30),18,Color.rgb(55,55,65),1));
        root.addView(note, lp(-1,-2,0,8,0,16));

        Button apply = button("Áp dụng", Color.rgb(113,83,255));
        apply.setOnClickListener(v -> apply(false));
        root.addView(apply, lp(-1,dp(56),0,0,0,10));

        Button test = button("Thử overlay 4 giây", Color.rgb(36,36,46));
        test.setOnClickListener(v -> apply(true));
        root.addView(test, lp(-1,dp(52),0,0,0,10));

        Button stop = button("Dừng dịch vụ", Color.rgb(36,36,46));
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this,"Đã dừng Shibu overlay",Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, lp(-1,dp(52),0,0,0,8));

        sizeBar.setOnSeekBarChangeListener(listener(this::updateLabels));
        offsetBar.setOnSeekBarChangeListener(listener(this::updateLabels));
        speedBar.setOnSeekBarChangeListener(listener(this::updateLabels));
        updateLabels();
        return scroll;
    }

    private void apply(boolean test) {
        savePrefs();
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivityForResult(i, 77);
            Toast.makeText(this,"Hãy bật Cho phép hiển thị trên cùng, rồi quay lại bấm Áp dụng",Toast.LENGTH_LONG).show();
            return;
        }
        Intent s = new Intent(this, OverlayService.class);
        s.setAction(test ? OverlayService.ACTION_TEST : OverlayService.ACTION_APPLY);
        startForegroundService(s);
        Toast.makeText(this, test ? "Đang thử hiệu ứng" : "Đã áp dụng Shibu Fingerprint", Toast.LENGTH_SHORT).show();
    }

    private void savePrefs() {
        Prefs.get(this).edit()
            .putInt(Prefs.ICON, iconIndex)
            .putInt(Prefs.ANIM, animIndex)
            .putInt(Prefs.SIZE, sizeBar.getProgress())
            .putInt(Prefs.OFFSET, offsetBar.getProgress())
            .putInt(Prefs.SPEED, speedBar.getProgress())
            .putBoolean(Prefs.SCREEN_ON, screenOn.isChecked())
            .apply();
    }

    private LinearLayout chipRow(String[] names, boolean icon) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i=0;i<names.length;i++) {
            final int idx=i;
            TextView t=text(names[i],14,Color.WHITE,false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(14),0,dp(14),0);
            t.setMinWidth(dp(92));
            t.setTag(i);
            t.setOnClickListener(v->{
                if(icon) iconIndex=idx; else animIndex=idx;
                refreshChips(); updatePreview();
            });
            row.addView(t, new LinearLayout.LayoutParams(-2,dp(48)));
            if(i<names.length-1) {
                View gap=new View(this); row.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
            }
        }
        return row;
    }

    private void refreshChips() {
        refreshRow(iconRow, iconIndex); refreshRow(animRow, animIndex);
    }
    private void refreshRow(LinearLayout row,int sel) {
        if(row==null)return;
        for(int i=0;i<row.getChildCount();i++) {
            View v=row.getChildAt(i);
            if(v instanceof TextView) {
                int idx=(Integer)v.getTag();
                v.setBackground(round(idx==sel?Color.rgb(42,35,68):Color.rgb(28,28,34),16,idx==sel?Color.rgb(139,111,255):Color.rgb(60,60,70), idx==sel?2:1));
            }
        }
    }

    private void updatePreview() {
        if(preview==null)return;
        preview.configure(iconIndex,animIndex,currentSpeed());
        refreshChips();
    }
    private void updateLabels() {
        if(sizeBar==null)return;
        sizeValue.setText((70 + sizeBar.getProgress()) + " dp");
        offsetValue.setText((80 + offsetBar.getProgress()) + " dp");
        speedValue.setText(String.format(java.util.Locale.US,"%.1fx", currentSpeed()));
        updatePreview();
    }
    private float currentSpeed(){ return 0.6f + (speedBar==null?50:speedBar.getProgress())/100f*1.2f; }

    private SeekBar.OnSeekBarChangeListener listener(Runnable r){
        return new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean f){r.run();}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        };
    }

    private HorizontalScrollView horizontal(View v){
        HorizontalScrollView h=new HorizontalScrollView(this); h.setHorizontalScrollBarEnabled(false); h.addView(v); return h;
    }
    private TextView section(String s){ TextView t=text(s,13,Color.rgb(175,175,186),true); t.setLetterSpacing(.08f); return t; }
    private TextView valueLabel(){ return text("",14,Color.rgb(172,151,255),true); }
    private LinearLayout settingHeader(String name,TextView val){
        LinearLayout l=new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(0,dp(6),0,0);
        TextView n=text(name,16,Color.WHITE,false); l.addView(n,new LinearLayout.LayoutParams(0,dp(36),1)); l.addView(val); return l;
    }
    private SeekBar bar(int min,int max,int p){ SeekBar b=new SeekBar(this); b.setMax(max); b.setProgress(Math.max(min,p)); return b; }
    private TextView text(String s,int sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private Button button(String s,int bg){ Button b=new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(bg,18,bg,0)); return b; }
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h); p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p; }
    private GradientDrawable round(int fill,int radius,int stroke,int sw){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radius)); if(sw>0)g.setStroke(dp(sw),stroke); return g; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
}
