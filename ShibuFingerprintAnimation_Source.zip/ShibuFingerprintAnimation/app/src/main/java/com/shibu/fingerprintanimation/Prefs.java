package com.shibu.fingerprintanimation;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "shibu_fp";
    public static final String ICON = "icon";
    public static final String ANIM = "anim";
    public static final String SIZE = "size";
    public static final String OFFSET = "offset";
    public static final String SPEED = "speed";
    public static final String SCREEN_ON = "screen_on";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
}
