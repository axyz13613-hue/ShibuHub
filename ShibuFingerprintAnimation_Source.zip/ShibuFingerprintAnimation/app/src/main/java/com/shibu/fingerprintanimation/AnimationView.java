package com.shibu.fingerprintanimation;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class AnimationView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float phase = 0f;
    private int iconStyle = 1;
    private int animationStyle = 0;
    private float speed = 1f;
    private ValueAnimator animator;

    public AnimationView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        startAnimator();
    }

    public void configure(int icon, int anim, float speedValue) {
        iconStyle = Math.max(0, Math.min(4, icon));
        animationStyle = Math.max(0, Math.min(4, anim));
        speed = Math.max(0.5f, Math.min(2.0f, speedValue));
        startAnimator();
        invalidate();
    }

    private void startAnimator() {
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration((long)(1500f / speed));
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) animator.cancel();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) * 0.30f;
        drawAnimation(c, cx, cy, r);
        drawIcon(c, cx, cy, r * 0.78f);
    }

    private void drawAnimation(Canvas c, float cx, float cy, float r) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(Math.max(3f, r * 0.055f));
        float pulse = (float)(0.5 + 0.5 * Math.sin(phase * Math.PI * 2));
        switch (animationStyle) {
            case 0: // Sakura burst
                for (int i = 0; i < 8; i++) {
                    double a = (i / 8.0) * Math.PI * 2 + phase * 1.8;
                    float rr = r * (0.65f + 0.42f * phase);
                    float x = cx + (float)Math.cos(a) * rr;
                    float y = cy + (float)Math.sin(a) * rr;
                    p.setColor(Color.argb((int)(210 * (1f - phase)), 255, 111 + i * 9, 190 + i * 4));
                    p.setStyle(Paint.Style.FILL);
                    c.save(); c.rotate((float)Math.toDegrees(a), x, y);
                    RectF petal = new RectF(x-r*.10f, y-r*.05f, x+r*.10f, y+r*.05f);
                    c.drawOval(petal, p); c.restore();
                }
                break;
            case 1: // Energy rings
                for (int i = 0; i < 3; i++) {
                    float t = (phase + i / 3f) % 1f;
                    p.setColor(Color.argb((int)(220 * (1f - t)), 132, 104 + i*30, 255));
                    p.setStyle(Paint.Style.STROKE);
                    c.drawCircle(cx, cy, r * (0.55f + t * 0.75f), p);
                }
                break;
            case 2: // Eclipse
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.argb(220, 190, 130, 255));
                p.setStrokeWidth(r * .10f);
                RectF arc = new RectF(cx-r*.92f, cy-r*.92f, cx+r*.92f, cy+r*.92f);
                c.drawArc(arc, phase * 360f, 210f, false, p);
                p.setColor(Color.argb(200, 255, 90, 160));
                c.drawArc(arc, phase * 360f + 190f, 90f, false, p);
                break;
            case 3: // Particles
                p.setStyle(Paint.Style.FILL);
                for (int i = 0; i < 14; i++) {
                    float t = (phase + i * .071f) % 1f;
                    double a = i * 2.399963 + phase * 2.2;
                    float rr = r * (.35f + .8f * t);
                    p.setColor(Color.argb((int)(255 * (1f - t)), 100 + (i*13)%155, 180, 255));
                    c.drawCircle(cx + (float)Math.cos(a)*rr, cy + (float)Math.sin(a)*rr, r*(.025f + .035f*(1-t)), p);
                }
                break;
            default: // Neon wave
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r*.045f);
                for (int k=0;k<3;k++) {
                    p.setColor(Color.argb(190-k*45, 80+k*70, 220-k*20, 255));
                    path.reset();
                    for (int i=0;i<=80;i++) {
                        float x = cx-r + 2*r*i/80f;
                        float y = cy + (float)Math.sin(i*.26 + phase*Math.PI*2 + k)*r*.22f;
                        if (i==0) path.moveTo(x,y); else path.lineTo(x,y);
                    }
                    c.drawPath(path,p);
                }
                break;
        }

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb((int)(35 + 35*pulse), 155, 105, 255));
        p.setShadowLayer(r * (.22f + .08f*pulse), 0, 0, Color.argb(180, 142, 89, 255));
        c.drawCircle(cx, cy, r*.58f, p);
        p.clearShadowLayer();
    }

    private void drawIcon(Canvas c, float cx, float cy, float r) {
        p.setStrokeWidth(Math.max(3f, r * .075f));
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Color.WHITE);
        p.setShadowLayer(r*.20f, 0, 0, Color.argb(230, 180, 110, 255));

        if (iconStyle == 0) {
            p.setColor(Color.argb(170,255,255,255));
            c.drawCircle(cx,cy,r*.72f,p);
            p.clearShadowLayer();
            return;
        }
        if (iconStyle == 1) {
            drawClassicFingerprint(c,cx,cy,r);
        } else if (iconStyle == 2) {
            c.drawCircle(cx, cy, r*.72f, p);
            c.drawCircle(cx, cy, r*.45f, p);
            c.drawCircle(cx, cy, r*.18f, p);
        } else if (iconStyle == 3) {
            for (int i=0;i<5;i++) {
                RectF a = new RectF(cx-r*(.78f-i*.12f),cy-r*(.78f-i*.12f),cx+r*(.78f-i*.12f),cy+r*(.78f-i*.12f));
                c.drawArc(a, 205+i*8, 130-i*12, false, p);
            }
        } else {
            // Shibu spiral crest
            for (int i=0;i<6;i++) {
                float ang = i*60f + phase*45f;
                c.save(); c.rotate(ang,cx,cy);
                RectF blade = new RectF(cx-r*.12f,cy-r*.78f,cx+r*.12f,cy-r*.12f);
                c.drawArc(blade,180,180,false,p);
                c.restore();
            }
            c.drawCircle(cx,cy,r*.18f,p);
        }
        p.clearShadowLayer();
    }

    private void drawClassicFingerprint(Canvas c,float cx,float cy,float r) {
        for (int i=0;i<5;i++) {
            float rr = r * (.30f + i*.12f);
            RectF oval = new RectF(cx-rr*.72f, cy-rr, cx+rr*.72f, cy+rr);
            c.drawArc(oval, 205f, 130f, false, p);
            c.drawArc(oval, 25f, 130f, false, p);
        }
        c.drawLine(cx,cy-r*.25f,cx,cy+r*.28f,p);
    }
}
