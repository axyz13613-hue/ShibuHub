# Shibu Fingerprint Animation 1.0

Ứng dụng Android không-root dành ưu tiên cho Samsung Galaxy A31 / Android 12.

## Chức năng
- 5 kiểu biểu tượng vân tay.
- 5 hoạt ảnh: Sakura, Energy, Eclipse, Particles, Neon.
- Xem trước trực tiếp.
- Chỉnh kích thước, vị trí từ đáy màn hình và tốc độ.
- Overlay không chặn cảm ứng (`FLAG_NOT_TOUCHABLE`).
- Tùy chọn tự hiện 4 giây khi màn hình bật.
- Nút thử overlay và dừng dịch vụ.

## Giới hạn kỹ thuật
Android không cấp cho ứng dụng thường quyền thay trực tiếp animation vân tay của Samsung SystemUI hoặc đọc sự kiện chạm cảm biến vân tay trên màn hình khóa. Ứng dụng này tạo lớp phủ độc lập. Một số bản One UI có thể chủ động ẩn overlay khi secure keyguard đang hiển thị.

## Build
Mở thư mục trong Android Studio, dùng JDK 17, Sync Gradle và Build APK.
- compileSdk 35
- minSdk 26
- targetSdk 31 (tối ưu cho Android 12 của A31)
- package: `com.shibu.fingerprintanimation`

## Dùng trên A31
1. Cài APK và mở ứng dụng.
2. Chọn icon/animation, chỉnh vị trí.
3. Bấm **Áp dụng**.
4. Cho phép **Hiển thị trên cùng** khi Android hỏi.
5. Quay lại app và bấm **Áp dụng** lần nữa.
6. Nếu hiệu ứng hơi lệch cảm biến, chỉnh thanh **Vị trí từ đáy màn hình**.
