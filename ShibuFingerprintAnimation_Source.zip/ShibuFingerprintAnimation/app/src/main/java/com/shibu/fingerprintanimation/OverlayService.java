package com.shibu.fingerprintanimation;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_APPLY = "com.shibu.fp.APPLY";
    public static final String ACTION_TEST = "com.shibu.fp.TEST";
    public static final String ACTION_STOP = "com.shibu.fp.STOP";
    private static final int NOTIF_ID = 1047;
    private static final String CHANNEL = "shibu_fp_overlay";
    private WindowManager wm;
    private AnimationView overlay;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean receiverRegistered;

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                if (Prefs.get(OverlayService.this).getBoolean(Prefs.SCREEN_ON,true)) showFor(4500);
            } else if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) hide();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        createChannel();
        startForeground(NOTIF_ID, notification());
        IntentFilter f=new IntentFilter(); f.addAction(Intent.ACTION_SCREEN_ON); f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenReceiver,f); receiverRegistered=true;
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        String action=intent==null?ACTION_APPLY:intent.getAction();
        if(ACTION_STOP.equals(action)){ stopSelf(); return START_NOT_STICKY; }
        if(!Settings.canDrawOverlays(this)){ stopSelf(); return START_NOT_STICKY; }
        if(ACTION_TEST.equals(action) || ACTION_APPLY.equals(action)) showFor(4500);
        return START_STICKY;
    }

    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,OverlayService.class); stop.setAction(ACTION_STOP);
        PendingIntent ps=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Shibu Fingerprint đang chạy")
            .setContentText("Overlay sẵn sàng cho màn hình khóa")
            .setContentIntent(pi).setOngoing(true)
            .addAction(new Notification.Action.Builder(null,"Dừng",ps).build()).build();
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Shibu Fingerprint Overlay",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Dịch vụ hiển thị hiệu ứng vân tay không root");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showFor(long ms){
        hide();
        SharedPreferences sp=Prefs.get(this);
        int sizeDp=70+sp.getInt(Prefs.SIZE,55);
        int offsetDp=80+sp.getInt(Prefs.OFFSET,95);
        float speed=.6f+sp.getInt(Prefs.SPEED,50)/100f*1.2f;
        overlay=new AnimationView(this);
        overlay.configure(sp.getInt(Prefs.ICON,1),sp.getInt(Prefs.ANIM,0),speed);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int wf=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(sizeDp),dp(sizeDp),type,wf,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
        p.y=dp(offsetDp);
        try { wm.addView(overlay,p); } catch(Exception e){ overlay=null; }
        h.postDelayed(this::hide,ms);
    }

    private void hide(){
        h.removeCallbacksAndMessages(null);
        if(overlay!=null){ try{ wm.removeView(overlay); }catch(Exception ignored){} overlay=null; }
    }

    @Override public void onDestroy(){
        hide();
        if(receiverRegistered){ try{unregisterReceiver(screenReceiver);}catch(Exception ignored){} receiverRegistered=false; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){ return null; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
}
